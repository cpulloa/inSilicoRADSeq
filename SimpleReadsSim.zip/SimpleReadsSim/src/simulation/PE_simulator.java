package simulation;
import java.io.PrintStream;
import ngsep.sequences.DNAMaskedSequence;
import ngsep.sequences.DNASequence;
import ngsep.sequences.QualifiedSequence;
import ngsep.sequences.QualifiedSequenceList;
import ngsep.sequences.io.FastaSequencesHandler;
/**
 * Processes simulator reads from fragements 
 * @author Cindy Ulloa, Jorge Duitama
 *
 */
public class PE_simulator {

		public static void main(String[] args) throws Exception {
			FastaSequencesHandler handler = new FastaSequencesHandler();
			QualifiedSequenceList sequences = handler.loadSequences(args[0]);
			int n = sequences.size();
			
			int partitionLen=400;
			int readLen=150;//atención!!
			
			
			String head_f="@read_";
			String head_f2="@read2_";
			CharSequence read1=null;
			CharSequence read12=null;
			CharSequence read2=null;
			CharSequence read22=null;
			CharSequence revComp=null;
			CharSequence revComp2=null;
			String quality = "";
			String text1="";
			String text2="";
			String pathFile=args[0];
			
			for(int i=0;i<n;i++) {
				QualifiedSequence seq = sequences.get(i);
				DNAMaskedSequence all_dna = (DNAMaskedSequence)seq.getCharacters();
				int MaxSize=all_dna.length();
				
				
				if(MaxSize>partitionLen){
					DNAMaskedSequence dna = (DNAMaskedSequence) all_dna.subSequence(0, partitionLen);
					DNAMaskedSequence dna2 = (DNAMaskedSequence) all_dna.subSequence(MaxSize-partitionLen, MaxSize);
				
					read1 = dna.subSequence(0, readLen);
					read12 = dna2.subSequence(0, readLen);
					revComp = dna.getReverseComplement();
					revComp2 = dna2.getReverseComplement();
					read2 = revComp.subSequence(0, readLen);
					read22 = revComp2.subSequence(0, readLen);
					
					for (int j=0; j<read1.length();j++){
						quality = "a"+quality;
					}
					if(i==0){
						text1=head_f+i+"/1"+"\n"+read1+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/1"+"\n"+read12+"\n"+"+"+"\n"+quality;
						text2=head_f+i+"/2"+"\n"+read2+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/2"+"\n"+read22+"\n"+"+"+"\n"+quality;
					}
					else{
						text1=text1+"\n"+head_f+i+"/1"+"\n"+read1+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/1"+"\n"+read12+"\n"+"+"+"\n"+quality;
						text2=text2+"\n"+head_f+i+"/2"+"\n"+read2+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/2"+"\n"+read22+"\n"+"+"+"\n"+quality;
					}
					//System.out.println(head_f+i+"/1"+"\n"+read1+"\n"+"+"+"\n"+quality);
					//System.out.println(head_f+i+"/2"+"\n"+read2+"\n"+"+"+"\n"+quality);
					quality ="";
					
				}
				else if(MaxSize>=readLen){
					DNAMaskedSequence dna = (DNAMaskedSequence) all_dna.subSequence(0, readLen);
					
					read1 = dna.subSequence(0, readLen);
					read12 = dna.subSequence(0, readLen);
					revComp = dna.getReverseComplement();
					revComp2 = dna.getReverseComplement();
					read2 = revComp.subSequence(0, readLen);
					read22 = revComp2.subSequence(0, readLen);
					
					for (int j=0; j<read1.length();j++){
						quality = "a"+quality;
					}
					if(i==0){
						text1=head_f+i+"/1"+"\n"+read1+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/1"+"\n"+read12+"\n"+"+"+"\n"+quality;
						text2=head_f+i+"/2"+"\n"+read2+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/2"+"\n"+read22+"\n"+"+"+"\n"+quality;
					}
					else{
						text1=text1+"\n"+head_f+i+"/1"+"\n"+read1+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/1"+"\n"+read12+"\n"+"+"+"\n"+quality;
						text2=text2+"\n"+head_f+i+"/2"+"\n"+read2+"\n"+"+"+"\n"+quality+"\n"+head_f2+i+"/2"+"\n"+read22+"\n"+"+"+"\n"+quality;
					}
					//System.out.println(head_f+i+"/1"+"\n"+read1+"\n"+"+"+"\n"+quality);
					//System.out.println(head_f+i+"/2"+"\n"+read2+"\n"+"+"+"\n"+quality);
					quality ="";
				}
		
				
			}
			pathFile=pathFile.replaceAll("-fragments.fasta","");
			pathFile.substring(pathFile.lastIndexOf("/") + 1);
			
			PrintStream fileStream = new PrintStream(pathFile+"_read1.fastq");
			fileStream.println(text1);
			fileStream.close();
			
			PrintStream fileStream2 = new PrintStream(pathFile+"_read2.fastq");
			fileStream2.println(text2);
			fileStream2.close();
			
		}
	}
